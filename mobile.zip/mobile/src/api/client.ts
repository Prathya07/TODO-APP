import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Android emulator reaches the host machine at 10.0.2.2.
// Physical device: use your PC's LAN IP, or run `adb reverse tcp:5000 tcp:5000` and use localhost.
export const API_URL = 'http://10.0.2.2:5000/api';
export const TOKEN_KEY = '@todo/token';

const client = axios.create({baseURL: API_URL, timeout: 10000});

// Attach the JWT to every request.
client.interceptors.request.use(async config => {
  const token = await AsyncStorage.getItem(TOKEN_KEY);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/** Turns any thrown error into a readable message for the UI. */
export function getErrorMessage(e: unknown): string {
  if (axios.isAxiosError(e)) {
    if (e.response?.data?.message) {
      return e.response.data.message;
    }
    if (!e.response) {
      return 'Cannot reach the server. Check that the backend is running.';
    }
  }
  return 'Something went wrong. Please try again.';
}

export default client;
