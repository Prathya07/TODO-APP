import React, {useEffect, useState} from 'react';
import {KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import Input from '../components/Input';
import PrimaryButton from '../components/PrimaryButton';
import {AuthStackParams} from '../navigation/RootNavigator';
import {useAppDispatch, useAppSelector} from '../store';
import {clearAuthError, login} from '../store/authSlice';
import {colors} from '../theme/colors';

type Props = NativeStackScreenProps<AuthStackParams, 'Login'>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen({navigation}: Props) {
  const dispatch = useAppDispatch();
  const {loading, error} = useAppSelector(s => s.auth);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{email?: string; password?: string}>({});

  // clear stale server errors when leaving the screen
  useEffect(() => () => {
    dispatch(clearAuthError());
  }, [dispatch]);

  const submit = () => {
    const next: typeof errors = {};
    if (!EMAIL_RE.test(email.trim())) {
      next.email = 'Enter a valid email';
    }
    if (!password) {
      next.password = 'Enter your password';
    }
    setErrors(next);
    if (Object.keys(next).length === 0) {
      dispatch(login({email: email.trim(), password}));
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.brand}>Deadline</Text>
        <Text style={styles.tagline}>Plan the day. Beat the clock.</Text>

        <View style={styles.form}>
          <Input
            label="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@example.com"
            error={errors.email}
          />
          <Input
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="Your password"
            error={errors.password}
          />
          {error ? <Text style={styles.serverError}>{error}</Text> : null}
          <PrimaryButton title="Log in" onPress={submit} loading={loading} />
        </View>

        <Pressable onPress={() => navigation.navigate('Register')} style={styles.link}>
          <Text style={styles.linkText}>
            New here? <Text style={{color: colors.primary, fontWeight: '700'}}>Create an account</Text>
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {flex: 1, backgroundColor: colors.bg},
  container: {flexGrow: 1, justifyContent: 'center', padding: 24},
  brand: {color: colors.text, fontSize: 44, fontWeight: '800', letterSpacing: -1},
  tagline: {color: colors.muted, fontSize: 16, marginTop: 4, marginBottom: 36},
  form: {marginBottom: 8},
  serverError: {color: colors.danger, marginBottom: 12},
  link: {alignItems: 'center', marginTop: 20},
  linkText: {color: colors.muted, fontSize: 15},
});
