import React, {useEffect, useState} from 'react';
import {KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View} from 'react-native';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import Input from '../components/Input';
import PrimaryButton from '../components/PrimaryButton';
import {AuthStackParams} from '../navigation/RootNavigator';
import {useAppDispatch, useAppSelector} from '../store';
import {clearAuthError, register} from '../store/authSlice';
import {colors} from '../theme/colors';

type Props = NativeStackScreenProps<AuthStackParams, 'Register'>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function RegisterScreen({navigation}: Props) {
  const dispatch = useAppDispatch();
  const {loading, error} = useAppSelector(s => s.auth);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => () => {
    dispatch(clearAuthError());
  }, [dispatch]);

  const submit = () => {
    const next: Record<string, string> = {};
    if (name.trim().length < 2) {
      next.name = 'Name must be at least 2 characters';
    }
    if (!EMAIL_RE.test(email.trim())) {
      next.email = 'Enter a valid email';
    }
    if (password.length < 6) {
      next.password = 'Password must be at least 6 characters';
    }
    if (confirm !== password) {
      next.confirm = 'Passwords do not match';
    }
    setErrors(next);
    if (Object.keys(next).length === 0) {
      // on success the token is stored and the navigator switches to the app stack
      dispatch(register({name: name.trim(), email: email.trim(), password}));
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Create your account</Text>
        <Text style={styles.sub}>Your tasks stay private and sync to your account.</Text>

        <View>
          <Input label="Name" value={name} onChangeText={setName} placeholder="Your name" error={errors.name} />
          <Input
            label="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@example.com"
            error={errors.email}
          />
          <Input
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="At least 6 characters"
            error={errors.password}
          />
          <Input
            label="Confirm password"
            value={confirm}
            onChangeText={setConfirm}
            secureTextEntry
            placeholder="Repeat your password"
            error={errors.confirm}
          />
          {error ? <Text style={styles.serverError}>{error}</Text> : null}
          <PrimaryButton title="Create account" onPress={submit} loading={loading} />
        </View>

        <Pressable onPress={() => navigation.goBack()} style={styles.link}>
          <Text style={styles.linkText}>
            Already have an account? <Text style={{color: colors.primary, fontWeight: '700'}}>Log in</Text>
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {flex: 1, backgroundColor: colors.bg},
  container: {flexGrow: 1, justifyContent: 'center', padding: 24},
  title: {color: colors.text, fontSize: 30, fontWeight: '800', letterSpacing: -0.5},
  sub: {color: colors.muted, fontSize: 15, marginTop: 4, marginBottom: 28},
  serverError: {color: colors.danger, marginBottom: 12},
  link: {alignItems: 'center', marginTop: 20},
  linkText: {color: colors.muted, fontSize: 15},
});
