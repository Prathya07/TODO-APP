import React, {useCallback, useEffect, useMemo} from 'react';
import {FlatList, Pressable, RefreshControl, StyleSheet, Text, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import FilterBar from '../components/FilterBar';
import TaskCard from '../components/TaskCard';
import {AppStackParams} from '../navigation/RootNavigator';
import {useAppDispatch, useAppSelector} from '../store';
import {logout} from '../store/authSlice';
import {clearTasksError, deleteTask, fetchTasks, toggleTask} from '../store/tasksSlice';
import {colors} from '../theme/colors';
import {sortTasks} from '../utils/smartSort';

type Props = NativeStackScreenProps<AppStackParams, 'Tasks'>;

export default function TasksScreen({navigation}: Props) {
  const dispatch = useAppDispatch();
  const user = useAppSelector(s => s.auth.user);
  const {items, loading, error, statusFilter, categoryFilter, sortMode} = useAppSelector(s => s.tasks);

  const load = useCallback(() => {
    dispatch(fetchTasks());
  }, [dispatch]);

  useEffect(load, [load]);

  // filter first, then sort the remaining tasks
  const visible = useMemo(() => {
    const filtered = items.filter(t => {
      if (statusFilter === 'active' && t.completed) {
        return false;
      }
      if (statusFilter === 'done' && !t.completed) {
        return false;
      }
      return !categoryFilter || t.category === categoryFilter;
    });
    return sortTasks(filtered, sortMode);
  }, [items, statusFilter, categoryFilter, sortMode]);

  const doneCount = items.filter(t => t.completed).length;
  const progress = items.length ? doneCount / items.length : 0;
  const firstName = user?.name.split(' ')[0] ?? '';

  return (
    <SafeAreaView style={styles.flex} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.hello}>Hi {firstName}</Text>
          <Text style={styles.count}>
            {items.length === 0 ? 'No tasks yet' : `${doneCount} of ${items.length} done`}
          </Text>
        </View>
        <Pressable onPress={() => dispatch(logout())} hitSlop={10}>
          <Text style={styles.logout}>Log out</Text>
        </Pressable>
      </View>

      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, {width: `${progress * 100}%`}]} />
      </View>

      <FilterBar />

      {error ? (
        <Pressable onPress={() => dispatch(clearTasksError())} style={styles.errorBox}>
          <Text style={styles.errorText}>{error} (tap to dismiss)</Text>
        </Pressable>
      ) : null}

      <FlatList
        data={visible}
        keyExtractor={t => t._id}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={load} tintColor={colors.primary} colors={[colors.primary]} />
        }
        contentContainerStyle={{paddingBottom: 110, paddingTop: 6}}
        renderItem={({item}) => (
          <TaskCard
            task={item}
            onToggle={() => dispatch(toggleTask(item._id))}
            onDelete={() => dispatch(deleteTask(item._id))}
            onPress={() => navigation.navigate('TaskForm', {task: item})}
          />
        )}
        ListEmptyComponent={
          loading ? null : (
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>
                {items.length === 0 ? 'Nothing planned yet' : 'No tasks match these filters'}
              </Text>
              <Text style={styles.emptySub}>
                {items.length === 0 ? 'Tap "New task" to add your first one.' : 'Try another status or category.'}
              </Text>
            </View>
          )
        }
      />

      <Pressable style={styles.fab} onPress={() => navigation.navigate('TaskForm')}>
        <Text style={styles.fabText}>+ New task</Text>
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: {flex: 1, backgroundColor: colors.bg},
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  hello: {color: colors.text, fontSize: 28, fontWeight: '800', letterSpacing: -0.5},
  count: {color: colors.muted, fontSize: 14, marginTop: 2},
  logout: {color: colors.muted, fontWeight: '600', paddingTop: 8},
  progressTrack: {
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.panelRaised,
    marginHorizontal: 20,
    marginTop: 14,
    marginBottom: 16,
    overflow: 'hidden',
  },
  progressFill: {height: 6, borderRadius: 3, backgroundColor: colors.calm},
  errorBox: {
    backgroundColor: colors.panelRaised,
    borderColor: colors.danger,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginHorizontal: 20,
    marginBottom: 10,
  },
  errorText: {color: colors.danger, fontSize: 13},
  empty: {alignItems: 'center', paddingTop: 70, paddingHorizontal: 40},
  emptyTitle: {color: colors.text, fontSize: 18, fontWeight: '700'},
  emptySub: {color: colors.muted, marginTop: 6, textAlign: 'center'},
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 28,
    backgroundColor: colors.primary,
    borderRadius: 28,
    paddingHorizontal: 22,
    paddingVertical: 15,
    elevation: 6,
  },
  fabText: {color: colors.onPrimary, fontWeight: '800', fontSize: 16},
});
