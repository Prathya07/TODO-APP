import React, {useState} from 'react';
import {Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import Chip from '../components/Chip';
import DateTimeField from '../components/DateTimeField';
import Input from '../components/Input';
import PrimaryButton from '../components/PrimaryButton';
import PriorityPicker from '../components/PriorityPicker';
import {AppStackParams} from '../navigation/RootNavigator';
import {useAppDispatch} from '../store';
import {createTask, updateTask} from '../store/tasksSlice';
import {colors} from '../theme/colors';
import {CATEGORIES, Priority} from '../types';

type Props = NativeStackScreenProps<AppStackParams, 'TaskForm'>;

/** One screen for both adding a task and editing an existing one. */
export default function TaskFormScreen({navigation, route}: Props) {
  const dispatch = useAppDispatch();
  const editing = route.params?.task;

  const [title, setTitle] = useState(editing?.title ?? '');
  const [description, setDescription] = useState(editing?.description ?? '');
  const [scheduledAt, setScheduledAt] = useState(editing ? new Date(editing.scheduledAt) : new Date());
  const [deadline, setDeadline] = useState(
    editing ? new Date(editing.deadline) : new Date(Date.now() + 24 * 3600 * 1000),
  );
  const [priority, setPriority] = useState<Priority>(editing?.priority ?? 'medium');
  const [category, setCategory] = useState(editing?.category ?? 'Personal');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<{title?: string; deadline?: string}>({});

  const save = async () => {
    const next: typeof errors = {};
    if (!title.trim()) {
      next.title = 'Give your task a title';
    }
    if (deadline < scheduledAt) {
      next.deadline = 'Deadline must be after the start time';
    }
    setErrors(next);
    if (Object.keys(next).length > 0) {
      return;
    }

    const input = {
      title: title.trim(),
      description: description.trim(),
      scheduledAt: scheduledAt.toISOString(),
      deadline: deadline.toISOString(),
      priority,
      category,
    };

    setSaving(true);
    // dispatch each thunk separately so TypeScript can infer its result type
    const result = editing
      ? await dispatch(updateTask({id: editing._id, input}))
      : await dispatch(createTask(input));
    setSaving(false);

    // unwrap manually so we can show the server message instead of crashing
    if (result.meta.requestStatus === 'fulfilled') {
      navigation.goBack();
    } else {
      Alert.alert('Could not save task', (result.payload as string) ?? 'Please try again.');
    }
  };

  return (
    <SafeAreaView style={styles.flex} edges={['top']}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Text style={styles.cancel}>Cancel</Text>
          </Pressable>
          <Text style={styles.heading}>{editing ? 'Edit task' : 'New task'}</Text>
          <View style={{width: 50}} />
        </View>

        <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
          <Input label="Title" value={title} onChangeText={setTitle} placeholder="What needs doing?" error={errors.title} />
          <Input
            label="Description"
            value={description}
            onChangeText={setDescription}
            placeholder="Add details (optional)"
            multiline
            style={{minHeight: 90, textAlignVertical: 'top'}}
          />

          <DateTimeField label="Starts" value={scheduledAt} onChange={setScheduledAt} />
          <DateTimeField label="Deadline" value={deadline} onChange={setDeadline} error={errors.deadline} />

          <PriorityPicker value={priority} onChange={setPriority} />

          <Text style={styles.label}>Category</Text>
          <View style={styles.chips}>
            {CATEGORIES.map(c => (
              <Chip key={c} label={c} active={category === c} onPress={() => setCategory(c)} />
            ))}
          </View>

          <View style={{marginTop: 24}}>
            <PrimaryButton title={editing ? 'Save changes' : 'Add task'} onPress={save} loading={saving} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: {flex: 1, backgroundColor: colors.bg},
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 14,
  },
  cancel: {color: colors.muted, fontWeight: '600'},
  heading: {color: colors.text, fontSize: 18, fontWeight: '800'},
  body: {padding: 20, paddingBottom: 40},
  label: {color: colors.muted, fontSize: 13, marginBottom: 8, fontWeight: '600'},
  chips: {flexDirection: 'row', flexWrap: 'wrap', rowGap: 8},
});
