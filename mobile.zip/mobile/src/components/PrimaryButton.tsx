import React from 'react';
import {ActivityIndicator, Pressable, StyleSheet, Text} from 'react-native';
import {colors} from '../theme/colors';

interface Props {
  title: string;
  onPress: () => void;
  loading?: boolean;
  variant?: 'solid' | 'ghost';
}

export default function PrimaryButton({title, onPress, loading, variant = 'solid'}: Props) {
  const solid = variant === 'solid';
  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      style={({pressed}) => [
        styles.base,
        solid ? styles.solid : styles.ghost,
        pressed && {opacity: 0.8},
      ]}>
      {loading ? (
        <ActivityIndicator color={solid ? colors.onPrimary : colors.primary} />
      ) : (
        <Text style={[styles.text, !solid && {color: colors.primary}]}>{title}</Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {borderRadius: 12, paddingVertical: 14, alignItems: 'center', justifyContent: 'center'},
  solid: {backgroundColor: colors.primary},
  ghost: {borderWidth: 1, borderColor: colors.border},
  text: {color: colors.onPrimary, fontSize: 16, fontWeight: '700'},
});
