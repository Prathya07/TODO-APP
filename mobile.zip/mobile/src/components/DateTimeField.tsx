import React from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import {DateTimePickerAndroid} from '@react-native-community/datetimepicker';
import {colors} from '../theme/colors';
import {formatDateTime} from '../utils/date';

interface Props {
  label: string;
  value: Date;
  onChange: (d: Date) => void;
  error?: string;
}

/** Android picks date first, then time, using the native dialogs. */
export default function DateTimeField({label, value, onChange, error}: Props) {
  const open = () => {
    DateTimePickerAndroid.open({
      value,
      mode: 'date',
      onChange: (e, date) => {
        if (e.type !== 'set' || !date) {
          return;
        }
        DateTimePickerAndroid.open({
          value: date,
          mode: 'time',
          onChange: (e2, withTime) => {
            if (e2.type === 'set' && withTime) {
              onChange(withTime);
            }
          },
        });
      },
    });
  };

  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>{label}</Text>
      <Pressable onPress={open} style={[styles.field, error ? {borderColor: colors.danger} : null]}>
        <Text style={styles.value}>{formatDateTime(value)}</Text>
        <Text style={styles.action}>Change</Text>
      </Pressable>
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {marginBottom: 16},
  label: {color: colors.muted, fontSize: 13, marginBottom: 6, fontWeight: '600'},
  field: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.panel,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 13,
  },
  value: {color: colors.text, fontSize: 16},
  action: {color: colors.primary, fontWeight: '600'},
  error: {color: colors.danger, fontSize: 12, marginTop: 4},
});
