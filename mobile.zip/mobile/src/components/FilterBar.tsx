import React from 'react';
import {ScrollView, StyleSheet, Text, View} from 'react-native';
import Chip from './Chip';
import {colors} from '../theme/colors';
import {useAppDispatch, useAppSelector} from '../store';
import {setCategoryFilter, setSortMode, setStatusFilter} from '../store/tasksSlice';
import {CATEGORIES, SortMode, StatusFilter} from '../types';

const STATUS: {key: StatusFilter; label: string}[] = [
  {key: 'all', label: 'All'},
  {key: 'active', label: 'Active'},
  {key: 'done', label: 'Done'},
];

const SORTS: {key: SortMode; label: string}[] = [
  {key: 'smart', label: 'Smart'},
  {key: 'deadline', label: 'Deadline'},
  {key: 'priority', label: 'Priority'},
  {key: 'time', label: 'Start time'},
];

/** Status, category and sort controls. State lives in Redux (tasksSlice). */
export default function FilterBar() {
  const dispatch = useAppDispatch();
  const {statusFilter, categoryFilter, sortMode} = useAppSelector(s => s.tasks);

  return (
    <View style={styles.wrap}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
        {STATUS.map(s => (
          <Chip key={s.key} label={s.label} active={statusFilter === s.key} onPress={() => dispatch(setStatusFilter(s.key))} />
        ))}
        <View style={styles.divider} />
        <Chip label="Any category" active={categoryFilter === null} onPress={() => dispatch(setCategoryFilter(null))} />
        {CATEGORIES.map(c => (
          <Chip key={c} label={c} active={categoryFilter === c} onPress={() => dispatch(setCategoryFilter(c))} />
        ))}
      </ScrollView>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
        <Text style={styles.sortLabel}>Sort by</Text>
        {SORTS.map(s => (
          <Chip key={s.key} label={s.label} active={sortMode === s.key} onPress={() => dispatch(setSortMode(s.key))} />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {gap: 10, marginBottom: 8},
  row: {paddingHorizontal: 20, alignItems: 'center'},
  divider: {width: 1, height: 20, backgroundColor: colors.border, marginRight: 8},
  sortLabel: {color: colors.muted, marginRight: 10, fontSize: 13},
});
