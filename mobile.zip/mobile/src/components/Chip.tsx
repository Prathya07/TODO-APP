import React from 'react';
import {Pressable, StyleSheet, Text} from 'react-native';
import {colors} from '../theme/colors';

interface Props {
  label: string;
  active: boolean;
  onPress: () => void;
}

/** Small selectable pill used for filters, sort modes and categories. */
export default function Chip({label, active, onPress}: Props) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && styles.active]}>
      <Text style={[styles.text, active && styles.activeText]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.panel,
    marginRight: 8,
  },
  active: {backgroundColor: colors.primary, borderColor: colors.primary},
  text: {color: colors.muted, fontWeight: '600', fontSize: 13},
  activeText: {color: colors.onPrimary},
});
