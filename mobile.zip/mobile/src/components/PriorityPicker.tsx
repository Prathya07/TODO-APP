import React from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import {colors, priorityColor} from '../theme/colors';
import {Priority} from '../types';

const OPTIONS: Priority[] = ['low', 'medium', 'high'];

interface Props {
  value: Priority;
  onChange: (p: Priority) => void;
}

/** Three-way segmented control; each segment uses its priority colour. */
export default function PriorityPicker({value, onChange}: Props) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>Priority</Text>
      <View style={styles.row}>
        {OPTIONS.map(p => {
          const active = p === value;
          return (
            <Pressable
              key={p}
              onPress={() => onChange(p)}
              style={[
                styles.seg,
                active && {backgroundColor: priorityColor[p], borderColor: priorityColor[p]},
              ]}>
              <Text style={[styles.segText, active && {color: colors.onPrimary}]}>
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {marginBottom: 16},
  label: {color: colors.muted, fontSize: 13, marginBottom: 6, fontWeight: '600'},
  row: {flexDirection: 'row', gap: 8},
  seg: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.panel,
  },
  segText: {color: colors.text, fontWeight: '700'},
});
