import React from 'react';
import {Alert, Pressable, StyleSheet, Text, View} from 'react-native';
import {colors, priorityColor} from '../theme/colors';
import {Task} from '../types';
import {formatDateTime, timeLeftLabel} from '../utils/date';

interface Props {
  task: Task;
  onToggle: () => void;
  onDelete: () => void;
  onPress: () => void;
}

/**
 * Share of the time window (start -> deadline) that has already passed.
 * Drives the urgency strip at the bottom of the card.
 */
function elapsedShare(task: Task, now = Date.now()): number {
  const start = new Date(task.scheduledAt).getTime();
  const end = new Date(task.deadline).getTime();
  if (end <= start) {
    return now >= end ? 1 : 0;
  }
  return Math.min(1, Math.max(0, (now - start) / (end - start)));
}

export default function TaskCard({task, onToggle, onDelete, onPress}: Props) {
  const share = elapsedShare(task);
  const overdue = !task.completed && new Date(task.deadline).getTime() < Date.now();
  // calm -> warn -> danger as the window runs out; mint when finished
  const strip = task.completed
    ? colors.calm
    : share < 0.6
    ? colors.calm
    : share < 0.85
    ? colors.warn
    : colors.danger;

  const confirmDelete = () =>
    Alert.alert('Delete task?', `"${task.title}" will be removed permanently.`, [
      {text: 'Cancel', style: 'cancel'},
      {text: 'Delete', style: 'destructive', onPress: onDelete},
    ]);

  return (
    <Pressable onPress={onPress} style={[styles.card, task.completed && {opacity: 0.6}]}>
      <View style={styles.top}>
        <Pressable
          onPress={onToggle}
          hitSlop={10}
          style={[styles.check, task.completed && styles.checkDone]}>
          {task.completed ? <Text style={styles.tick}>✓</Text> : null}
        </Pressable>

        <View style={{flex: 1}}>
          <Text style={[styles.title, task.completed && styles.titleDone]} numberOfLines={2}>
            {task.title}
          </Text>
          {task.description ? (
            <Text style={styles.desc} numberOfLines={2}>
              {task.description}
            </Text>
          ) : null}
        </View>

        <Pressable onPress={confirmDelete} hitSlop={10}>
          <Text style={styles.delete}>Delete</Text>
        </Pressable>
      </View>

      <View style={styles.meta}>
        <View style={[styles.pill, {borderColor: priorityColor[task.priority]}]}>
          <Text style={[styles.pillText, {color: priorityColor[task.priority]}]}>{task.priority}</Text>
        </View>
        <View style={styles.pill}>
          <Text style={styles.pillText}>{task.category}</Text>
        </View>
        <Text style={[styles.when, overdue && {color: colors.danger}]}>
          {task.completed ? 'Completed' : timeLeftLabel(task.deadline)}
        </Text>
      </View>

      <Text style={styles.dates}>
        Starts {formatDateTime(task.scheduledAt)}  ·  Deadline {formatDateTime(task.deadline)}
      </Text>

      {/* urgency strip: fills as the deadline approaches */}
      <View style={styles.track}>
        <View style={[styles.fill, {width: `${(task.completed ? 1 : share) * 100}%`, backgroundColor: strip}]} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.panel,
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  top: {flexDirection: 'row', alignItems: 'flex-start', gap: 12},
  check: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  checkDone: {backgroundColor: colors.calm, borderColor: colors.calm},
  tick: {color: colors.onPrimary, fontWeight: '800', fontSize: 14},
  title: {color: colors.text, fontSize: 17, fontWeight: '700'},
  titleDone: {textDecorationLine: 'line-through', color: colors.muted},
  desc: {color: colors.muted, fontSize: 14, marginTop: 3},
  delete: {color: colors.danger, fontSize: 13, fontWeight: '600'},
  meta: {flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14},
  pill: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    paddingHorizontal: 9,
    paddingVertical: 3,
  },
  pillText: {color: colors.muted, fontSize: 12, fontWeight: '700'},
  when: {marginLeft: 'auto', color: colors.text, fontSize: 13, fontWeight: '600'},
  dates: {color: colors.muted, fontSize: 12, marginTop: 10},
  track: {height: 4, borderRadius: 2, backgroundColor: colors.panelRaised, marginTop: 12, overflow: 'hidden'},
  fill: {height: 4, borderRadius: 2},
});
