export type Priority = 'low' | 'medium' | 'high';

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Task {
  _id: string;
  title: string;
  description: string;
  scheduledAt: string; // ISO date string
  deadline: string; // ISO date string
  priority: Priority;
  category: string;
  completed: boolean;
  createdAt: string;
}

/** Fields the user edits in the task form. */
export type TaskInput = Pick<
  Task,
  'title' | 'description' | 'scheduledAt' | 'deadline' | 'priority' | 'category'
>;

export type StatusFilter = 'all' | 'active' | 'done';
export type SortMode = 'smart' | 'deadline' | 'priority' | 'time';

export const CATEGORIES = ['Work', 'Personal', 'Study', 'Health', 'Other'];
