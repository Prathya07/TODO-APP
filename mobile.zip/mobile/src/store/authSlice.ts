import {createAsyncThunk, createSlice} from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import client, {TOKEN_KEY, getErrorMessage} from '../api/client';
import {User} from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  loading: boolean;
  bootstrapped: boolean; // true once we've checked storage for a saved session
  error: string | null;
}

const initialState: AuthState = {
  user: null,
  token: null,
  loading: false,
  bootstrapped: false,
  error: null,
};

type AuthResponse = {token: string; user: User};

/** On app launch: restore the saved session if the token is still valid. */
export const bootstrapAuth = createAsyncThunk('auth/bootstrap', async () => {
  const token = await AsyncStorage.getItem(TOKEN_KEY);
  if (!token) {
    return null;
  }
  try {
    const {data} = await client.get<{user: User}>('/auth/me');
    return {token, user: data.user};
  } catch (e) {
    // Only discard the token if the server says it is invalid (not on network errors).
    if (axios.isAxiosError(e) && e.response?.status === 401) {
      await AsyncStorage.removeItem(TOKEN_KEY);
    }
    return null;
  }
});

export const register = createAsyncThunk<
  AuthResponse,
  {name: string; email: string; password: string},
  {rejectValue: string}
>('auth/register', async (body, {rejectWithValue}) => {
  try {
    const {data} = await client.post<AuthResponse>('/auth/register', body);
    await AsyncStorage.setItem(TOKEN_KEY, data.token);
    return data;
  } catch (e) {
    return rejectWithValue(getErrorMessage(e));
  }
});

export const login = createAsyncThunk<
  AuthResponse,
  {email: string; password: string},
  {rejectValue: string}
>('auth/login', async (body, {rejectWithValue}) => {
  try {
    const {data} = await client.post<AuthResponse>('/auth/login', body);
    await AsyncStorage.setItem(TOKEN_KEY, data.token);
    return data;
  } catch (e) {
    return rejectWithValue(getErrorMessage(e));
  }
});

export const logout = createAsyncThunk('auth/logout', async () => {
  await AsyncStorage.removeItem(TOKEN_KEY);
});

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearAuthError(state) {
      state.error = null;
    },
  },
  extraReducers: builder => {
    builder
      .addCase(bootstrapAuth.fulfilled, (state, action) => {
        state.bootstrapped = true;
        state.token = action.payload?.token ?? null;
        state.user = action.payload?.user ?? null;
      })
      .addCase(bootstrapAuth.rejected, state => {
        state.bootstrapped = true;
      })
      .addCase(logout.fulfilled, state => {
        state.token = null;
        state.user = null;
      });

    // login + register share the same state transitions
    for (const thunk of [login, register]) {
      builder
        .addCase(thunk.pending, state => {
          state.loading = true;
          state.error = null;
        })
        .addCase(thunk.fulfilled, (state, action) => {
          state.loading = false;
          state.token = action.payload.token;
          state.user = action.payload.user;
        })
        .addCase(thunk.rejected, (state, action) => {
          state.loading = false;
          state.error = action.payload ?? 'Something went wrong';
        });
    }
  },
});

export const {clearAuthError} = authSlice.actions;
export default authSlice.reducer;
