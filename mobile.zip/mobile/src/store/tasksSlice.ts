import {PayloadAction, createAsyncThunk, createSlice} from '@reduxjs/toolkit';
import client, {getErrorMessage} from '../api/client';
import {SortMode, StatusFilter, Task, TaskInput} from '../types';
import {logout} from './authSlice';

interface TasksState {
  items: Task[];
  loading: boolean;
  error: string | null;
  // UI state for the list screen lives here so it survives navigation
  statusFilter: StatusFilter;
  categoryFilter: string | null;
  sortMode: SortMode;
}

const initialState: TasksState = {
  items: [],
  loading: false,
  error: null,
  statusFilter: 'all',
  categoryFilter: null,
  sortMode: 'smart',
};

type Rejectable = {rejectValue: string};

export const fetchTasks = createAsyncThunk<Task[], void, Rejectable>(
  'tasks/fetch',
  async (_, {rejectWithValue}) => {
    try {
      const {data} = await client.get<{tasks: Task[]}>('/tasks');
      return data.tasks;
    } catch (e) {
      return rejectWithValue(getErrorMessage(e));
    }
  },
);

export const createTask = createAsyncThunk<Task, TaskInput, Rejectable>(
  'tasks/create',
  async (input, {rejectWithValue}) => {
    try {
      const {data} = await client.post<{task: Task}>('/tasks', input);
      return data.task;
    } catch (e) {
      return rejectWithValue(getErrorMessage(e));
    }
  },
);

export const updateTask = createAsyncThunk<
  Task,
  {id: string; input: TaskInput},
  Rejectable
>('tasks/update', async ({id, input}, {rejectWithValue}) => {
  try {
    const {data} = await client.put<{task: Task}>(`/tasks/${id}`, input);
    return data.task;
  } catch (e) {
    return rejectWithValue(getErrorMessage(e));
  }
});

export const toggleTask = createAsyncThunk<Task, string, Rejectable>(
  'tasks/toggle',
  async (id, {rejectWithValue}) => {
    try {
      const {data} = await client.patch<{task: Task}>(`/tasks/${id}/toggle`);
      return data.task;
    } catch (e) {
      return rejectWithValue(getErrorMessage(e));
    }
  },
);

export const deleteTask = createAsyncThunk<string, string, Rejectable>(
  'tasks/delete',
  async (id, {rejectWithValue}) => {
    try {
      await client.delete(`/tasks/${id}`);
      return id;
    } catch (e) {
      return rejectWithValue(getErrorMessage(e));
    }
  },
);

const flip = (items: Task[], id: string) => {
  const t = items.find(x => x._id === id);
  if (t) {
    t.completed = !t.completed;
  }
};

const tasksSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    setStatusFilter(state, a: PayloadAction<StatusFilter>) {
      state.statusFilter = a.payload;
    },
    setCategoryFilter(state, a: PayloadAction<string | null>) {
      state.categoryFilter = a.payload;
    },
    setSortMode(state, a: PayloadAction<SortMode>) {
      state.sortMode = a.payload;
    },
    clearTasksError(state) {
      state.error = null;
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchTasks.pending, state => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTasks.fulfilled, (state, a) => {
        state.loading = false;
        state.items = a.payload;
      })
      .addCase(fetchTasks.rejected, (state, a) => {
        state.loading = false;
        state.error = a.payload ?? 'Could not load tasks';
      })
      .addCase(createTask.fulfilled, (state, a) => {
        state.items.push(a.payload);
      })
      .addCase(updateTask.fulfilled, (state, a) => {
        const i = state.items.findIndex(t => t._id === a.payload._id);
        if (i >= 0) {
          state.items[i] = a.payload;
        }
      })
      // Optimistic toggle: flip immediately, undo if the server call fails.
      .addCase(toggleTask.pending, (state, a) => flip(state.items, a.meta.arg))
      .addCase(toggleTask.rejected, (state, a) => {
        flip(state.items, a.meta.arg);
        state.error = a.payload ?? 'Could not update task';
      })
      .addCase(deleteTask.fulfilled, (state, a) => {
        state.items = state.items.filter(t => t._id !== a.payload);
      })
      .addCase(deleteTask.rejected, (state, a) => {
        state.error = a.payload ?? 'Could not delete task';
      })
      // Wipe local tasks when the user logs out so the next account starts clean.
      .addCase(logout.fulfilled, () => initialState);
  },
});

export const {setStatusFilter, setCategoryFilter, setSortMode, clearTasksError} =
  tasksSlice.actions;
export default tasksSlice.reducer;
