import {Priority, SortMode, Task} from '../types';

const PRIORITY_WEIGHT: Record<Priority, number> = {high: 3, medium: 2, low: 1};

/**
 * Urgency in (0, 1.5]: 1.5 when overdue, otherwise decays smoothly from ~1
 * (due now) towards 0 (far away). Half-life is about one day.
 */
export function urgency(deadlineIso: string, now = Date.now()): number {
  const hoursLeft = (new Date(deadlineIso).getTime() - now) / 36e5;
  return hoursLeft <= 0 ? 1.5 : 1 / (1 + hoursLeft / 24);
}

/**
 * Smart score mixes priority and deadline proximity.
 * priority contributes 10-30 points, urgency 0-60 points, so a low priority task
 * that is overdue still outranks a high priority task due next week.
 */
export function smartScore(task: Task, now = Date.now()): number {
  return PRIORITY_WEIGHT[task.priority] * 10 + urgency(task.deadline, now) * 40;
}

const byDeadline = (a: Task, b: Task) =>
  new Date(a.deadline).getTime() - new Date(b.deadline).getTime();

/** Returns a new sorted array. Completed tasks always sink to the bottom. */
export function sortTasks(tasks: Task[], mode: SortMode, now = Date.now()): Task[] {
  const compare = (a: Task, b: Task): number => {
    switch (mode) {
      case 'smart':
        return smartScore(b, now) - smartScore(a, now) || byDeadline(a, b);
      case 'priority':
        return PRIORITY_WEIGHT[b.priority] - PRIORITY_WEIGHT[a.priority] || byDeadline(a, b);
      case 'time':
        return new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime();
      default:
        return byDeadline(a, b);
    }
  };
  return [...tasks].sort((a, b) => Number(a.completed) - Number(b.completed) || compare(a, b));
}
