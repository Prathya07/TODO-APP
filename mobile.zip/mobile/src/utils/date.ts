const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "12 Oct, 3:30 PM" */
export function formatDateTime(iso: string | Date): string {
  const d = new Date(iso);
  const h = d.getHours();
  const m = String(d.getMinutes()).padStart(2, '0');
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${d.getDate()} ${MONTHS[d.getMonth()]}, ${hour12}:${m} ${h >= 12 ? 'PM' : 'AM'}`;
}

/** Human readable distance to a deadline: "Due in 3h", "Overdue by 2d". */
export function timeLeftLabel(deadlineIso: string, now = Date.now()): string {
  const diff = new Date(deadlineIso).getTime() - now;
  const abs = Math.abs(diff);
  const mins = Math.floor(abs / 60000);
  const hours = Math.floor(mins / 60);
  const days = Math.floor(hours / 24);
  const span = days > 0 ? `${days}d` : hours > 0 ? `${hours}h` : `${Math.max(mins, 1)}m`;
  return diff < 0 ? `Overdue by ${span}` : `Due in ${span}`;
}
