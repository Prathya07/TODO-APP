// Design tokens. Urgency drives colour: calm mint -> amber -> coral as a deadline nears.
export const colors = {
  bg: '#121528', // midnight
  panel: '#1C2040',
  panelRaised: '#262B52',
  border: '#313766',
  text: '#EDEFFF',
  muted: '#8F95C0',
  primary: '#9D8CFF', // lavender
  onPrimary: '#14112E',
  calm: '#5EEAD4', // mint
  warn: '#FFC857', // amber
  danger: '#FF6B81', // coral
};

export const priorityColor = {
  low: colors.calm,
  medium: colors.warn,
  high: colors.danger,
} as const;
