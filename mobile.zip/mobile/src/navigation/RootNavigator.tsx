import React, {useEffect} from 'react';
import {ActivityIndicator, View} from 'react-native';
import {DarkTheme, NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {useAppDispatch, useAppSelector} from '../store';
import {bootstrapAuth} from '../store/authSlice';
import {colors} from '../theme/colors';
import {Task} from '../types';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import TasksScreen from '../screens/TasksScreen';
import TaskFormScreen from '../screens/TaskFormScreen';

export type AuthStackParams = {Login: undefined; Register: undefined};
export type AppStackParams = {Tasks: undefined; TaskForm: {task?: Task} | undefined};

const AuthStack = createNativeStackNavigator<AuthStackParams>();
const AppStack = createNativeStackNavigator<AppStackParams>();

const navTheme = {
  ...DarkTheme,
  colors: {...DarkTheme.colors, background: colors.bg, card: colors.bg, text: colors.text, border: colors.border},
};

/** Shows the auth screens or the app screens depending on whether a token exists. */
export default function RootNavigator() {
  const dispatch = useAppDispatch();
  const {token, bootstrapped} = useAppSelector(s => s.auth);

  // restore saved session once on launch
  useEffect(() => {
    dispatch(bootstrapAuth());
  }, [dispatch]);

  if (!bootstrapped) {
    return (
      <View style={{flex: 1, backgroundColor: colors.bg, justifyContent: 'center'}}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer theme={navTheme}>
      {token ? (
        <AppStack.Navigator screenOptions={{headerShown: false, contentStyle: {backgroundColor: colors.bg}}}>
          <AppStack.Screen name="Tasks" component={TasksScreen} />
          <AppStack.Screen name="TaskForm" component={TaskFormScreen} />
        </AppStack.Navigator>
      ) : (
        <AuthStack.Navigator screenOptions={{headerShown: false, contentStyle: {backgroundColor: colors.bg}}}>
          <AuthStack.Screen name="Login" component={LoginScreen} />
          <AuthStack.Screen name="Register" component={RegisterScreen} />
        </AuthStack.Navigator>
      )}
    </NavigationContainer>
  );
}
