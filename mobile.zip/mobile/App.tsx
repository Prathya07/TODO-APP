import React from 'react';
import {StatusBar} from 'react-native';
import {Provider} from 'react-redux';
import {store} from './src/store';
import RootNavigator from './src/navigation/RootNavigator';
import {colors} from './src/theme/colors';

/** App root: Redux provider + navigation. */
export default function App() {
  return (
    <Provider store={store}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <RootNavigator />
    </Provider>
  );
}
