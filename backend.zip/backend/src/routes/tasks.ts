import { Router } from 'express';
import { z } from 'zod';
import { Task } from '../models/Task';
import { AuthRequest, requireAuth } from '../middleware/auth';

const router = Router();
router.use(requireAuth); // every task route needs a logged-in user

const taskSchema = z
  .object({
    title: z.string().trim().min(1, 'Title is required').max(120),
    description: z.string().trim().max(1000).default(''),
    scheduledAt: z.coerce.date(),
    deadline: z.coerce.date(),
    priority: z.enum(['low', 'medium', 'high']).default('medium'),
    category: z.string().trim().min(1).default('Personal'),
  })
  .refine((t) => t.deadline >= t.scheduledAt, {
    message: 'Deadline must be after the scheduled time',
    path: ['deadline'],
  });

// GET /api/tasks - all tasks of the current user
router.get('/', async (req: AuthRequest, res, next) => {
  try {
    const tasks = await Task.find({ user: req.userId }).sort({ deadline: 1 });
    res.json({ tasks });
  } catch (e) {
    next(e);
  }
});

// POST /api/tasks
router.post('/', async (req: AuthRequest, res, next) => {
  try {
    const data = taskSchema.parse(req.body);
    const task = await Task.create({ ...data, user: req.userId });
    res.status(201).json({ task });
  } catch (e) {
    next(e);
  }
});

// PUT /api/tasks/:id - edit a task
router.put('/:id', async (req: AuthRequest, res, next) => {
  try {
    const data = taskSchema.parse(req.body);
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      data,
      { new: true },
    );
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ task });
  } catch (e) {
    next(e);
  }
});

// PATCH /api/tasks/:id/toggle - flip completed / not completed
router.patch('/:id/toggle', async (req: AuthRequest, res, next) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    task.completed = !task.completed;
    task.completedAt = task.completed ? new Date() : null;
    await task.save();
    res.json({ task });
  } catch (e) {
    next(e);
  }
});

// DELETE /api/tasks/:id
router.delete('/:id', async (req: AuthRequest, res, next) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ id: req.params.id });
  } catch (e) {
    next(e);
  }
});

export default router;
