import { Schema, model } from 'mongoose';

export interface IUser {
  name: string;
  email: string;
  password: string; // bcrypt hash, never the raw password
}

const userSchema = new Schema<IUser>(
  {
    name: { type: String, required: true, trim: true },
    // unique index guarantees one account per email
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
  },
  { timestamps: true },
);

export const User = model<IUser>('User', userSchema);
