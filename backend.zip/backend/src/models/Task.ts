import { Schema, model, Types } from 'mongoose';

export type Priority = 'low' | 'medium' | 'high';

export interface ITask {
  user: Types.ObjectId; // owner - every query is scoped to this
  title: string;
  description: string;
  scheduledAt: Date; // when the user plans to start the task
  deadline: Date; // when it must be finished
  priority: Priority;
  category: string;
  completed: boolean;
  completedAt?: Date | null;
}

const taskSchema = new Schema<ITask>(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, default: '', trim: true, maxlength: 1000 },
    scheduledAt: { type: Date, required: true },
    deadline: { type: Date, required: true },
    priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
    category: { type: String, default: 'Personal', trim: true },
    completed: { type: Boolean, default: false },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true },
);

export const Task = model<ITask>('Task', taskSchema);
