import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';

export interface AuthRequest extends Request {
  userId?: string;
}

/** Signs a JWT that carries the user id. */
export function signToken(userId: string): string {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET as string, {
    expiresIn: (process.env.JWT_EXPIRES_IN || '7d') as jwt.SignOptions['expiresIn'],
  });
}

/** Protects routes: expects "Authorization: Bearer <token>". */
export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Missing auth token' });
  }
  try {
    const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET as string);
    req.userId = payload.sub as string;
    next();
  } catch {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}
